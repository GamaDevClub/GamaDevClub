'use strict';
const axios = require('axios')

 /**
  * Helpers para construir respostas que correspondam à estrutura das ações de diálogo necessárias 
  */ 
 function elicitSlot(sessionAttributes, intentName, slots, slotToElicit, message, responseCard) {
	return {
		sessionAttributes,
		dialogAction: {
			type: 'ElicitSlot',
			intentName,
			slots,
			slotToElicit,
			message,
			responseCard,
		},
	};
}

function confirmIntent(sessionAttributes, intentName, slots, message, responseCard) {
	return {
		sessionAttributes,
		dialogAction: {
			type: 'ConfirmIntent',
			intentName,
			slots,
			message,
			responseCard,
		},
	};
}

function close(sessionAttributes, fulfillmentState, message, responseCard) {
	return {
		sessionAttributes,
		dialogAction: {
			type: 'Close',
			fulfillmentState,
			message,
			responseCard,
		},
	};
}

function delegate(sessionAttributes, slots) {
	return {
		sessionAttributes,
		dialogAction: {
			type: 'Delegate',
			slots,
		},
	};
}

function buildMessage(messageContent) {
    return {
		contentType: 'PlainText',
		content: messageContent,
    };
}

function buildResponseCard(title, subTitle, options) {
    let buttons = null;
    if (options !== null) {
        buttons = [];
        for (let i = 0; i < Math.min(5, options.length); i++) {
            buttons.push(options[i]);
        }
    }
    return {
        contentType: 'application/vnd.amazonaws.card.generic',
        version: 1,
        genericAttachments: [{
            title,
            subTitle,
            buttons,
        }],
    };
}

function imageResponseCard(title, subTitle, imageUrl, attachmentLinkUrl, options) {
	let buttons = null;
    if (options !== null) {
        buttons = [];
        for (let i = 0; i < Math.min(5, options.length); i++) {
            buttons.push(options[i]);
        }
    }
	return {
	  contentType: 'application/vnd.amazonaws.card.generic',
      version: 1,
      genericAttachments: [{
	      title,
	      subTitle,
	      imageUrl,
	      attachmentLinkUrl,
	      buttons,
      }],
	};
}

function buildResponseOptions(optionsArray = Array){
    var responseOptions = [];
    for(var i=0; i<optionsArray.length; i++){
        var temp = {
            "text": optionsArray[i],
            "value": optionsArray[i]
        }
        responseOptions.push(temp);
    }
    return responseOptions;
}

function keyExists(key, search) {
    if (!search || (search.constructor !== Array && search.constructor !== Object)) {
        return false;
    }
    for (var i = 0; i < search.length; i++) {
        if (search[i] === key) {
            return true;
        }
    }
    return key in search;
}

async function getProductById(productId) {
	const urlProduto = `https://${process.env.ACCOUNT_NAME}.${process.env.ENVIRONMENT}.com.br/api/catalog_system/pub/products/crossselling/whosawalsosaw/${productId}`;
    const response = await axios.get(urlProduto,
	    {
	      headers: {
	        'x-vtex-api-appkey': process.env.VTEX_API_KEY,
	        'x-vtex-api-apptoken': process.env.VTEX_API_TOKEN,
	        'accept': 'application/json',
	        'content-type': 'application/json'
	      } 
	    }
	  );
    return response.data;	  
}

async function getProductBySearch(term) {
	const urlProduto = `https://${process.env.ACCOUNT_NAME}.${process.env.ENVIRONMENT}.com.br/api/catalog_system/pub/products/search/${term}`;
    const response = await axios.get(urlProduto,
	    {
	      headers: {
	        'x-vtex-api-appkey': process.env.VTEX_API_KEY,
	        'x-vtex-api-apptoken': process.env.VTEX_API_TOKEN,
	        'accept': 'application/json',
	        'content-type': 'application/json'
	      } 
	    }
	  );
    return response.data;	  
}

async function sugestaoProdutos(intentRequest, callback) {
	const outputSessionAttributes = intentRequest.sessionAttributes;
	const source = intentRequest.invocationSource;

	if (source === 'DialogCodeHook') {
		const slots = intentRequest.currentIntent.slots;	
	    const confirmaProduto = (slots.confirmaproduto ? slots.confirmaproduto : null); 
	
	    if (confirmaProduto) {
		    const produto = await getProductById(1);
		    console.log(produto);
		    const link = produto[0].link;
		    console.log(link);
		    
		    const brandImgUrl = produto[0].brandImageUrl ? produto[0].brandImageUrl : 'https://www.loja.canon.com.br/wcsstore/CDBCatalogAssetStore/sl3_nova_01_principal.jpg';
		    const menu = [{
				            "text": "Ver produto",
				            "value": link
        				 }]
		    
		    callback(
		      elicitSlot(
		        outputSessionAttributes, 
		        intentRequest.currentIntent.name, 
		        slots, 
		        'confirmaproduto', 
		        buildMessage(`Confira o produto que separamos para você:`), 
		        imageResponseCard(produto[0].productTitle, produto[0].metaTagDescription, brandImgUrl, link, menu)));
		}
		
		// retorna o fluxo para Lex
		callback(delegate(outputSessionAttributes, slots));
		return;
	}

	callback(
    close(
      outputSessionAttributes, 
      'Fulfilled', 
      {
        contentType: 'PlainText',
        content: `Mensagem de finalização! ${intentRequest.currentIntent.slots.confirmaProduto}`
      })
  );
}

async function searchProdutos(intentRequest, callback) {
	const outputSessionAttributes = intentRequest.sessionAttributes;
	const source = intentRequest.invocationSource;

	const slots = intentRequest.currentIntent.slots;	
    const keyBusca = (slots.searchProduto ? slots.searchProduto : 'apple'); 

    if (keyBusca) {
	    const produto = await getProductBySearch(keyBusca);
	    
	    if (produto.length > 0) {
		    let genRet = [];
		    const maxProd = produto.length > 5 ? 5 : produto.length;
	
		    for (let i = 0; i < maxProd; i++){
			    const link = produto[i].link; 
			    const prodTitle = produto[i].productTitle.substr(0, 70);
			    const prodDesc = 
			    	produto[i].metaTagDescription.substr(0, 40) == "" ? 
			    	"Ver mais detalhes de " + produto[i].productTitle.substr(0, 30) : 
			    	produto[i].metaTagDescription.substr(0, 40) + '...';
			    
			    const brandImgUrl = produto[i].items[0].images[0].imageUrl;
			    const menu = [{ "text": "Ver produto", "value": link }];
			    
			    genRet.push({
			    		'title': prodTitle,
			    		'subTitle': prodDesc,
			    		'imageUrl': brandImgUrl,
			    		'attachmentLinkUrl': link,
			    		'buttons': [{ 'text': 'Ver produto', 'value': link }]
			    	});
		    };
			
		    callback(
		      elicitSlot(
		        outputSessionAttributes, 
		        intentRequest.currentIntent.name, 
		        slots, 
		        'searchProduto', 
		        buildMessage(`Encontramos ${produto.length} produtos: `), 
		        {
					"version": 1,
					"contentType": "application/vnd.amazonaws.card.generic",
					"genericAttachments": genRet
		        }
		       
		     )
		   );
		   
	    } else {
			callback(
			    close(
			      outputSessionAttributes, 
			      'Fulfilled', 
			      {
			        contentType: 'PlainText',
			        content: `Não encontramos produtos com o termo ${keyBusca}. Tente novamente.`
			      })
			  );
	    }
    }
	
	// retorna o fluxo para Lex
	callback(delegate(outputSessionAttributes, slots));
	return;
}

function dispatch(intentRequest, callback) {

	console.log(`dispatch userId=${intentRequest.userId}, intent=${intentRequest.currentIntent.name}`);

	const name = intentRequest.currentIntent.name;

	// dispatch to the intent handlers
	if (name.startsWith('Produto_leia')) {
		return sugestaoProdutos(intentRequest, callback);
	}
	
	// dispatch to the intent handlers
	if (name.startsWith('Produto_busca')) {
		return searchProdutos(intentRequest, callback);
	}
	throw new Error(`Intent com nome ${name} não suportado`);
}
 

exports.handler = (event, context, callback) => {

	console.log(JSON.stringify(event));

	try {
		console.log(`event.bot.name=${event.bot.name}`);

		if(! event.bot.name.startsWith('leiabot_dev')) {
		    callback('O nome do bot é invalido');
		}
    
    dispatch(event, (response) => callback(null, response));
    
	} catch (err) {
		callback(err);
	}
};